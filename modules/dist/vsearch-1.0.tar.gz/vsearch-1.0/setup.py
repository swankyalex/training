from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='My first module',
    author='SwankyAlex',
    author_email='antilevski@tut.by',
    py_modules='vsearch'
)
